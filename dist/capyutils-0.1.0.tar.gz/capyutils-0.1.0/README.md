Collection of lightweight utils for diversified purposes
