from .results import Result as Result
